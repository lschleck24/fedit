#include "mu.h"

int 
main(int argc, char *argv[])
{
    /* 
     * TODO: delete the two MU_UNUSED lines below (they are just there so that
     * this file compiles without warnings) and implement the project.  You'll
     * want to parse the command-line arguments in main and create other
     * functions as needed.
     */
    MU_UNUSED(argc);
    MU_UNUSED(argv);
    
    return 0;
}
